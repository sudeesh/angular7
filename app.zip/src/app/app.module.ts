import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { HeadermenuComponent } from './headermenu/headermenu.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations'
import {SharedModule} from 'src/app/shared.Module';
@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    HeadermenuComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    SharedModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
