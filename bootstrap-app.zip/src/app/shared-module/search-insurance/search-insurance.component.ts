import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-insurance',
  templateUrl: './search-insurance.component.html',
  styleUrls: ['./search-insurance.component.scss']
})
export class SearchInsuranceComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
  getQuotes() {
    //   this._searchCriteria.keyWord = this.searchText;
    //   this._searchCriteria.pageIndex = Constants.searchCriteria.startPage;
    //   this._searchCriteria.pageSize = Constants.searchCriteria.startPageSize;
    //   this._searchCriteria.isSolrCatalogSearchEnabled = this.sharedData.purchaseWorkbenchPermission.isSolrCatalogSearchEnabled;
    //   this._searchCriteria.isFacetCatalogSearchEnabled = this.sharedData.purchaseWorkbenchPermission.isFacetCatalogSearchEnabled;
    //   this._searchCriteria.isNewSearch = true;
    //   this._searchCriteria.isFacetedSearch = false;
    //   this._searchCriteria.catalogId = 0;
    //   this._searchCriteria.facetCriteria = null;
    //   this._searchCriteria.filters = null;
    //   this._searchCriteria.isFilterSelected = false;
    //   this._searchCriteria.isL2CatalogFilterRequired = false;
    //   this._searchCriteria.level1EntityId = 0;
    //   this._searchCriteria.selectedIsPreferredSupplierFacet = null;
    //   this._searchCriteria.selectedManufacturFacet = null;
    //   this._searchCriteria.selectedManufacturList = null;
    //   this._searchCriteria.selectedDiversityClassificationFacet = null;
    //   this._searchCriteria.selectedDiversityClassificationList = null;
    //   this._searchCriteria.selectedPriceFacet = null;
    //   this._searchCriteria.selectedSupplierFacet = null;
    //   this._searchCriteria.supplierId = 0;
    //   this._searchCriteria.defaultCurrencyCode = this.sharedData.currencyCode;
    //   if (!this.sharedData.purchaseWorkbenchPermission.isSolrCatalogSearchEnabled) {
    //       this._searchCriteria.sortColumn = Constants.searchCriteria.activePrice;
    //       this._searchCriteria.sortOrder = Constants.searchCriteria.sortOrderAscending;
    //   }
    //   this._sharedDataService.productSearchCriteria = this._searchCriteria;
    //   if (this._router.url !== ("/" + Constants.uiRoutes.shopresult)) { //if not on shop result, navigate to it
    //       let link = [Constants.uiRoutes.shopresult];
    //       this._router.navigate(link);
    //   } else { //otherwise raise event to refresh results
    //       this._notificationService.notifyInitiateProductSearch(this._searchCriteria);
    //   }
  }
}
